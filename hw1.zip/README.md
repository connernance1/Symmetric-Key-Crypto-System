# CS5460:Computer Security I
# Fall2020

## Coding Style

### Hw1.py is the driver code that runs and utilizes the functions from all of the other files. 

### For Ease of testing I added suggestions for each task to enter as the input.